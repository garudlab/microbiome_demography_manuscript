# Supplement

This directory includes all supplemental figures and tables.

A zipped archive of all supplemental figures and tables can be found at [`./mah2023demography_supplement.zip`](./mah2023demography_supplement.zip)
